/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javapractical10inheritence;

/**
 *
 * @author RC_Student_lab
 */


   
  
class Person{//Base or Parent Class
   //Attributes
   String name;
   int age;
   
   //Constructor for a person Class
   Person(String name, int age){
     this.name = name;
     this.age = age;
   }
   
  //Method to display animal details
 void displayInfo(){
    System.out.println("Name: " + name);
    System.out.println("Age: " + age);
 }
 
 //Method to make a sound
 void walk(){
    System.out.println("The person makes a sound");
 }
   
}
    

