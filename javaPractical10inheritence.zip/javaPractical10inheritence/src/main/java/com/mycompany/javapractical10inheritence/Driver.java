/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javapractical10inheritence;

/**
 *
 * @author RC_Student_lab
 */
public class Driver extends Person{//Child class
     //Aditional atribute for driver
     String License;//String LicenseType
     
     //Constructor
    public Driver(String name, int age, String License) {
        super(name, age);//Call the constructors of the base
        this.License = License;
    }
   
   

    //Method to display driver details
    @Override
    void displayInfo(){
        super.displayInfo();//Call the method from the main class
      System.out.println("Drivers license type: " + License);
    }
}
    

