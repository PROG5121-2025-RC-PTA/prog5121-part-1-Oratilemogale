/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javapractical10inheritence;

/**
 *
 * @author RC_Student_lab
 */
public class Rider  extends Person{
    
    int Fee;
   
    public Rider(String name, int age, int fee){
       super(name, age);
       String fe = Integer.toString(fee);
       this.Fee = fee;
           
    }
    @Override
     void displayInfo(){
        super.displayInfo();//Call the method from the main class
      System.out.println("Rider Fee" + Fee);
    }
}
    

