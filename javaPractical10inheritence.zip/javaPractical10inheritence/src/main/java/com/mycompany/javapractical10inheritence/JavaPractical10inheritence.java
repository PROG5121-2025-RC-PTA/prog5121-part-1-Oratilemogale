/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javapractical10inheritence;

/**
 *
 * @author RC_Student_lab
 */
public class JavaPractical10inheritence 

   { //This is the default java class, all the other classes belong to this class

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { //This is the main method
        // Create a Person objectie
        Person newPerson = new Person("Genric Person",5);
        newPerson.displayInfo();//
        newPerson.walk();//
       
        System.out.println();
       
       //Creat a Driver objct
        Rider newdriver = new Rider("A200", 3, 100);
        newdriver.displayInfo();
        newdriver.walk();
    } //This is the end of the main method  
   
    //Insert classes here(Inheritance)
   
} //This is the end of the default java class

