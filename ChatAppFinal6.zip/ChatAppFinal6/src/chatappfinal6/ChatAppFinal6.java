/*
 * ChatAppFinal6 - Complete Messaging System
 
 */
package chatappfinal6;

import java.util.*;
import javax.swing.JOptionPane;

public class ChatAppFinal6 {

    // ========== PART 1: USER REGISTRATION ==========
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;
    private String username;

    public ChatAppFinal6(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Username validation (must contain _ and be ≤9 chars)
    public boolean checkUserName(String username) {
        return username.length() <= 9 && username.contains("_");
    }

    // Password validation (12+ chars with capital, number & special char)
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 12) return false;
        
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    // SA cell number validation (+27 followed by 9 digits)
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber.matches("^\\+27\\d{9}$");
    }

    // Complete user registration
    public String registerUser(String username, String password, String cellNumber) {
        if (!checkUserName(username)) {
            return "Username must contain _ and be ≤9 characters";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password needs 12+ chars with capital, number & special char";
        }
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell number must be SA format (+27 followed by 9 digits)";
        }
        
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
        return "Registration successful for " + firstName + " " + lastName;
    }

    // User login verification
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    // Login status message
    public String returnLoginStatus(boolean isLoggedIn) {
        return isLoggedIn 
            ? "Welcome " + firstName + " " + lastName + ", it is great to see you again."
            : "Username or password incorrect, please try again.";
    }

    // ========== PART 2: BASIC MESSAGING ==========
    public static class Message {
        private String id;
        private String recipient;
        private String content;
        private String hash;

        public Message(String id, String recipient, String content) {
            this.id = id;
            this.recipient = recipient;
            this.content = content;
            generateHash();
        }

        private void generateHash() {
            String firstTwo = id.substring(0, 2);
            String[] words = content.trim().split(" ");
            String firstWord = words[0].toUpperCase();
            String lastWord = words.length > 1 ? words[words.length-1].toUpperCase() : firstWord;
            this.hash = firstTwo + ":" + firstWord + lastWord;
        }

        public void printMessage() {
            System.out.println("\nMessage Details:");
            System.out.println("ID: " + id);
            System.out.println("To: " + recipient);
            System.out.println("Content: " + content);
            System.out.println("Hash: " + hash);
        }
    }

    public static class MessageManager {
        private ArrayList<Message> messages = new ArrayList<>();
        private int totalSent = 0;

        public boolean isValidRecipient(String number) {
            return number.startsWith("+") && number.length() <= 13;
        }

        public String generateMessageID() {
            return "MSG" + new Random().nextInt(90000) + 10000;
        }

        public void sendMessage(Message msg) {
            messages.add(msg);
            totalSent++;
            System.out.println("Message sent successfully!");
        }

        public void storeMessage(Message msg) {
            messages.add(msg);
            System.out.println("Message stored for later.");
        }

        public int getTotalSent() {
            return totalSent;
        }

        public List<Message> getMessages() {
            return messages;
        }
    }

    // ========== PART 3: ADVANCED MESSAGE MANAGEMENT ==========
    public static class AdvancedMessageManager {
        private Map<String, Message> messageDatabase = new HashMap<>();
        
        public void addMessage(Message msg) {
            messageDatabase.put(msg.id, msg);
        }
        
        public Message findMessageById(String id) {
            return messageDatabase.get(id);
        }
        
        public List<Message> findMessagesByRecipient(String recipient) {
            List<Message> results = new ArrayList<>();
            for (Message msg : messageDatabase.values()) {
                if (msg.recipient.equals(recipient)) {
                    results.add(msg);
                }
            }
            return results;
        }
        
        public boolean deleteMessage(String id) {
            return messageDatabase.remove(id) != null;
        }
        
        public void generateReport() {
            System.out.println("\n=== MESSAGE SYSTEM REPORT ===");
            System.out.println("Generated: " + new Date());
            System.out.println("Total messages: " + messageDatabase.size());
            System.out.println("-----------------------------------------------");
            System.out.printf("%-12s | %-15s | %-30s | %-10s%n", 
                            "Message ID", "Recipient", "Content", "Hash");
            System.out.println("-----------------------------------------------");
            
            for (Message msg : messageDatabase.values()) {
                String shortContent = msg.content.length() > 30 
                    ? msg.content.substring(0, 27) + "..." 
                    : msg.content;
                System.out.printf("%-12s | %-15s | %-30s | %-10s%n", 
                                msg.id, msg.recipient, shortContent, msg.hash);
            }
        }
    }

    // ========== MAIN APPLICATION ==========
    public static void main(String[] args) {
        // Registration
        String firstName = JOptionPane.showInputDialog("Enter first name:");
        String lastName = JOptionPane.showInputDialog("Enter last name:");
        ChatAppFinal6 app = new ChatAppFinal6(firstName, lastName);
        
        String username = JOptionPane.showInputDialog("Create username:");
        String password = JOptionPane.showInputDialog("Create password:");
        String cell = JOptionPane.showInputDialog("Enter SA cell number (+27xxxxxxxxx):");
        
        String regResult = app.registerUser(username, password, cell);
        JOptionPane.showMessageDialog(null, regResult);
        
        if (regResult.contains("successful")) {
            // Login
            String loginUser = JOptionPane.showInputDialog("Login username:");
            String loginPass = JOptionPane.showInputDialog("Login password:");
            
            boolean loggedIn = app.loginUser(loginUser, loginPass);
            JOptionPane.showMessageDialog(null, app.returnLoginStatus(loggedIn));
            
            if (loggedIn) {
                Scanner scanner = new Scanner(System.in);
                MessageManager basicManager = new MessageManager();
                AdvancedMessageManager advancedManager = new AdvancedMessageManager();
                boolean running = true;
                
                while (running) {
                    System.out.println("\n=== CHAT APPLICATION MENU ===");
                    System.out.println("1. Send Basic Message");
                    System.out.println("2. Advanced Message Management");
                    System.out.println("3. Exit");
                    System.out.print("Choose option: ");
                    
                    String choice = scanner.nextLine();
                    
                    switch (choice) {
                        case "1":
                            // Basic messaging from Part 2
                            System.out.print("Recipient number (+countrycode): ");
                            String rec = scanner.nextLine();
                            
                            if (!basicManager.isValidRecipient(rec)) {
                                System.out.println("Invalid recipient format");
                                break;
                            }
                            
                            System.out.print("Message content: ");
                            String content = scanner.nextLine();
                            
                            if (content.length() > 250) {
                                System.out.println("Message too long (max 250 chars)");
                                break;
                            }
                            
                            Message newMsg = new Message(
                                basicManager.generateMessageID(), rec, content);
                            
                            System.out.print("Action (send/store): ");
                            String action = scanner.nextLine().toLowerCase();
                            
                            if (action.equals("send")) {
                                basicManager.sendMessage(newMsg);
                                advancedManager.addMessage(newMsg); // Also add to advanced system
                            } else if (action.equals("store")) {
                                basicManager.storeMessage(newMsg);
                                advancedManager.addMessage(newMsg);
                            } else {
                                System.out.println("Invalid action");
                            }
                            break;
                            
                        case "2":
                            // Advanced management from Part 3
                            boolean inAdvancedMenu = true;
                            while (inAdvancedMenu) {
                                System.out.println("\n=== ADVANCED MESSAGE MANAGEMENT ===");
                                System.out.println("1. Find Message by ID");
                                System.out.println("2. Find Messages by Recipient");
                                System.out.println("3. Delete Message");
                                System.out.println("4. Generate Report");
                                System.out.println("5. Back to Main Menu");
                                System.out.print("Choose option: ");
                                
                                String advChoice = scanner.nextLine();
                                
                                switch (advChoice) {
                                    case "1":
                                        System.out.print("Enter message ID: ");
                                        Message found = advancedManager.findMessageById(scanner.nextLine());
                                        if (found != null) found.printMessage();
                                        else System.out.println("Message not found");
                                        break;
                                        
                                    case "2":
                                        System.out.print("Enter recipient number: ");
                                        List<Message> recipientMessages = 
                                            advancedManager.findMessagesByRecipient(scanner.nextLine());
                                        if (recipientMessages.isEmpty()) {
                                            System.out.println("No messages found");
                                        } else {
                                            System.out.println("Found " + recipientMessages.size() + " messages:");
                                            for (Message msg : recipientMessages) {
                                                msg.printMessage();
                                            }
                                        }
                                        break;
                                        
                                    case "3":
                                        System.out.print("Enter message ID to delete: ");
                                        boolean deleted = advancedManager.deleteMessage(scanner.nextLine());
                                        System.out.println(deleted ? "Message deleted" : "Message not found");
                                        break;
                                        
                                    case "4":
                                        advancedManager.generateReport();
                                        break;
                                        
                                    case "5":
                                        inAdvancedMenu = false;
                                        break;
                                        
                                    default:
                                        System.out.println("Invalid option");
                                }
                            }
                            break;
                            
                        case "3":
                            running = false;
                            System.out.println("Thank you for using the chat application!");
                            System.out.println("Total messages sent: " + basicManager.getTotalSent());
                            break;
                            
                        default:
                            System.out.println("Invalid option");
                    }
                }
            }
        }
    }
}
