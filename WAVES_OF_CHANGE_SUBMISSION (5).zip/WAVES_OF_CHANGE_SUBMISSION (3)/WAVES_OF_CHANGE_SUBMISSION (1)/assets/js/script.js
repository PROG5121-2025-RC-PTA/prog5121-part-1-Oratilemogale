// Waves of Change - basic interactivity (no external libs)
document.addEventListener('DOMContentLoaded', () => {
  const yearSpan = document.querySelector('[data-year]');
  if (yearSpan) yearSpan.textContent = new Date().getFullYear();

  const pledgeInputs = document.querySelectorAll('[data-pledge]');
  const pledgeTotal = document.querySelector('[data-pledge-total]');
  function updateTotal(){
    let t = 0;
    pledgeInputs.forEach(i => t += Number(i.value) || 0);
    if (pledgeTotal) pledgeTotal.textContent = t.toLocaleString();
  }
  pledgeInputs.forEach(i => i.addEventListener('input', updateTotal));
  updateTotal();

  const backToTop = document.getElementById('backToTop');
  if (backToTop){
    backToTop.addEventListener('click', () => window.scrollTo({top:0, behavior:'smooth'}));
  }

  const newsletterForm = document.getElementById('newsletterForm');
  if (newsletterForm){
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = newsletterForm.querySelector('input[type="email"]').value.trim();
      if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
        alert('Please enter a valid email address.');
        return;
      }
      alert('Thanks for subscribing to Waves of Change!');
      newsletterForm.reset();
    });
  }
});