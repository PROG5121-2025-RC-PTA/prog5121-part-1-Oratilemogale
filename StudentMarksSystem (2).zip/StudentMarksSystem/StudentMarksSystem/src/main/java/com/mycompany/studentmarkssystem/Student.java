/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmarkssystem;

/**
 *
 * @author RC_Student_lab
 */
// Student.java

public class Student extends Person {
    private int[] marks;   // array to hold student marks
    private int subjectCount; // number of subjects
    private int index;     // keeps track of entered marks

    // constructor
    public Student(String name, int subjectCount) {
        super(name); // call to Person constructor
        this.subjectCount = subjectCount;
        this.marks = new int[subjectCount]; // advanced array concept
        this.index = 0;
    }

    // method to add a mark
    public void addMark(int mark) {
        if (index < marks.length) {
            marks[index] = mark;
            index++;
        }
    }

    // calculate average
    public double calculateAverage() {
        int total = 0;
        for (int i = 0; i < marks.length; i++) {
            total = total + marks[i];
        }
        return (double) total / marks.length;
    }

    // find highest mark
    public int getHighestMark() {
        int highest = marks[0];
        for (int i = 0; i < marks.length; i++) {
            if (marks[i] > highest) {
                highest = marks[i];
            }
        }
        return highest;
    }

    // find lowest mark
    public int getLowestMark() {
        int lowest = marks[0];
        for (int i = 0; i < marks.length; i++) {
            if (marks[i] < lowest) {
                lowest = marks[i];
            }
        }
        return lowest;
    }
}

