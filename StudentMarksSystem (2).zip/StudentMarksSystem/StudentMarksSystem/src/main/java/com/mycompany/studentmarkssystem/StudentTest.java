/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmarkssystem;

/**
 *
 * @author RC_Student_lab
 */

// StudentTest.java
public class StudentTest {

    
    public void testAverageCalculation() {
        Student s = new Student("Tester", 3);
        s.addMark(60);
        s.addMark(70);
        s.addMark(80);
        assertEquals(70.0, s.calculateAverage(), 0.01);
    }

    
    public void testHighestMark() {
        Student s = new Student("Tester", 3);
        s.addMark(45);
        s.addMark(75);
        s.addMark(65);
        assertEquals(75, s.getHighestMark(), 0.01);
    }

    
    public void testLowestMark() {
        Student s = new Student("Tester", 3);
        s.addMark(45);
        s.addMark(75);
        s.addMark(65);
        assertEquals(45, s.getLowestMark(), 0.01);
    }

    private void assertEquals(double i, double lowestMark, double par1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
