/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmarkssystem;

/**
 *
 * @author RC_Student_lab
 */

// MainApp.java
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to the Student Marks System");
        System.out.print("Enter student name: ");
        String name = input.nextLine();

        System.out.print("Enter number of subjects: ");
        int numSubjects = input.nextInt();

        // create student object
        Student s = new Student(name, numSubjects);

        // loop for marks
        for (int i = 0; i < numSubjects; i++) {
            System.out.print("Enter mark for subject " + (i + 1) + ": ");
            int mark = input.nextInt();
            s.addMark(mark);
        }

        // show report
        StudentReport.printReport(s);

        System.out.println("Thank you for using the system.");
        input.close();
    }
}
