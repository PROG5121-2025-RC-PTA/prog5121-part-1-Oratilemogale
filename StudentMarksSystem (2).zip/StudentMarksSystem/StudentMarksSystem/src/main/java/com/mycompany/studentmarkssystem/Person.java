/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmarkssystem;

/**
 *
 * @author RC_Student_lab
 */
// Person.java
// This is the base class (Inheritance concept)
public class Person {
    private String name; // information hiding with private

    // creator
    public Person(String name) {
        this.name = name;
    }

    // finder
    public String getName() {
        return name;
    }

    // placer
    public void setName(String name) {
        this.name = name;
    }
}

