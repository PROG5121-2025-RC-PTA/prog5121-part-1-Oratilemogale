/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentmarkssystem;

/**
 *
 * @author RC_Student_lab
 */

// StudentReport.java
// This class prints out the student report
public class StudentReport {

    public static void printReport(Student student) {
        System.out.println("===================================");
        System.out.println("        STUDENT REPORT             ");
        System.out.println("-----------------------------------");
        System.out.println("Student Name: " + student.getName());
        System.out.println("Average Mark: " + student.calculateAverage());
        System.out.println("Highest Mark: " + student.getHighestMark());
        System.out.println("Lowest Mark: " + student.getLowestMark());
        System.out.println("===================================");
    }
}

