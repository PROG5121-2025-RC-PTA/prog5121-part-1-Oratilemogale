/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.seriesapplication;

import java.util.ArrayList;
import java.util.Scanner;

public class SeriesApplication {
    private final Scanner input = new Scanner(System.in);
    private final ArrayList<TVSeries> seriesCollection = new ArrayList<>();

    public static void main(String[] args) {
        SeriesApplication manager = new SeriesApplication();
        Scanner console = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== TV Series Database ===");
            System.out.println("Press (M) for Menu or any other key to quit:");
            String choice = console.nextLine();

            if (choice.equalsIgnoreCase("M")) {
                manager.mainMenu();
            } else {
                System.out.println("Exiting program... Goodbye!");
                break;
            }
        }
        console.close();
    }

    private void mainMenu() {
        while (true) {
            System.out.println("\n---- Main Menu ----");
            System.out.println("1. Register Series");
            System.out.println("2. Find Series");
            System.out.println("3. Edit Series");
            System.out.println("4. Remove Series");
            System.out.println("5. Show All Series");
            System.out.println("6. Back to Main");
            System.out.print("Your option: ");
            String option = input.nextLine();

            switch (option) {
                case "1": registerSeries(); break;
                case "2": findSeries(); break;
                case "3": editSeries(); break;
                case "4": removeSeries(); break;
                case "5": displayAll(); break;
                case "6": return;
                default: System.out.println("Invalid input. Try again.");
            }
        }
    }

    // Add new series
    private void registerSeries() {
        System.out.print("Enter ID: ");
        String id = input.nextLine();

        System.out.print("Enter Title: ");
        String title = input.nextLine();

        System.out.print("Enter Creator: ");
        String creator = input.nextLine();

        int ageLimit;
        while (true) {
            System.out.print("Enter Age Restriction (2 - 18): ");
            try {
                ageLimit = Integer.parseInt(input.nextLine());
                if (ageLimit >= 2 && ageLimit <= 18) break;
                else System.out.println("Age must be between 2 and 18.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Try again.");
            }
        }

        int totalEpisodes;
        while (true) {
            System.out.print("Enter number of Episodes (min 2): ");
            try {
                totalEpisodes = Integer.parseInt(input.nextLine());
                if (totalEpisodes >= 2) break;
                else System.out.println("Series must have at least 2 episodes.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Try again.");
            }
        }

        TVSeries newSeries = new TVSeries(id, title, creator, ageLimit, totalEpisodes);
        seriesCollection.add(newSeries);
        System.out.println("Series successfully registered!");
    }

    // Search series
    private void findSeries() {
        System.out.print("Enter ID to search: ");
        String id = input.nextLine();

        for (TVSeries s : seriesCollection) {
            if (s.getId().equalsIgnoreCase(id)) {
                s.showDetails();
                return;
            }
        }
        System.out.println("No series found with ID: " + id);
    }

    // Update series
    private void editSeries() {
        System.out.print("Enter ID to update: ");
        String id = input.nextLine();

        for (TVSeries s : seriesCollection) {
            if (s.getId().equalsIgnoreCase(id)) {
                System.out.print("New Title: ");
                s.setTitle(input.nextLine());

                System.out.print("New Creator: ");
                s.setCreator(input.nextLine());

                int newAge;
                while (true) {
                    System.out.print("New Age Restriction (2-18): ");
                    try {
                        newAge = Integer.parseInt(input.nextLine());
                        if (newAge >= 2 && newAge <= 18) {
                            s.setAgeRestriction(newAge);
                            break;
                        }
                        System.out.println("Invalid range. Try again.");
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Try again.");
                    }
                }

                int newEpisodes;
                while (true) {
                    System.out.print("New Episodes (min 2): ");
                    try {
                        newEpisodes = Integer.parseInt(input.nextLine());
                        if (newEpisodes >= 2) {
                            s.setEpisodes(newEpisodes);
                            break;
                        }
                        System.out.println("Must have at least 2 episodes.");
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Try again.");
                    }
                }

                System.out.println("Series updated successfully!");
                return;
            }
        }
        System.out.println("Series not found.");
    }

    // Delete series
    private void removeSeries() {
        System.out.print("Enter ID to delete: ");
        String id = input.nextLine();

        for (int i = 0; i < seriesCollection.size(); i++) {
            if (seriesCollection.get(i).getId().equalsIgnoreCase(id)) {
                seriesCollection.remove(i);
                System.out.println("Series deleted.");
                return;
            }
        }
        System.out.println("Series not found.");
    }

    // Report
    private void displayAll() {
        if (seriesCollection.isEmpty()) {
            System.out.println("No series available.");
            return;
        }
        System.out.println("\n=== All Series ===");
        for (TVSeries s : seriesCollection) {
            s.showDetails();
        }
    }
}

// Model class
class TVSeries {
    private String id;
    private String title;
    private String creator;
    private int ageRestriction;
    private int episodes;

    public TVSeries(String id, String title, String creator, int ageRestriction, int episodes) {
        this.id = id;
        this.title = title;
        this.creator = creator;
        this.ageRestriction = ageRestriction;
        this.episodes = episodes;
    }

    public String getId() { return id; }
    public void setTitle(String title) { this.title = title; }
    public void setCreator(String creator) { this.creator = creator; }
    public void setAgeRestriction(int age) { this.ageRestriction = age; }
    public void setEpisodes(int episodes) { this.episodes = episodes; }

    public void showDetails() {
        System.out.println("ID: " + id);
        System.out.println("Title: " + title);
        System.out.println("Creator: " + creator);
        System.out.println("Age Restriction: " + ageRestriction);
        System.out.println("Episodes: " + episodes);
        System.out.println("--------------------");
    }
}

