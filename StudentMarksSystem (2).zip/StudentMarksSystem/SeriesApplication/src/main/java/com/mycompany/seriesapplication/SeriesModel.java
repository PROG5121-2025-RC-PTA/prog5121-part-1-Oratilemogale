/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.seriesapplication;

/**
 *
 * @author RC_Student_lab
 */
public class SeriesModel {
   
    String seriesId;
    String seriesTitle;
    String seriesCreator;
    String seriesEpisodes;

    public SeriesModel(String id, String title, String creator, String episodes) {
        this.seriesId = id;
        this.seriesTitle = title;
        this.seriesCreator = creator;
        this.seriesEpisodes = episodes;
    }
}
