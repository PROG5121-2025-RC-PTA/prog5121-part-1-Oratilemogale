/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inheritanceprac;
import java.util.Scanner;
/**
 *
 * @author iramatladi
 */


// Main class to run the application
public class InheritancePrac {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the name");
        String name = scanner.nextLine();
        
        System.out.print("please enter the age");
        int age = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("enter the license type");
        String license = scanner.nextLine();
        // Create an Animal object
       /* Animal animal = new Animal("Generic Animal", 5);//Create 
        animal.displayInfo();//From the Person Class
        animal.makeSound();//Walk method from the Person Class*/

        System.out.println();

        // Create a Dog object
        Dog dog = new Dog(name, age, license);
        System.out.println();
        dog.displayInfo();
        dog.makeSound();
        
        scanner.close();
    }
}

// Base class
class Animal {
    // Attributes
    String name;
    int age;
    // Constructor for the Person Class
    Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }
    // Method to display animal details
    void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
    // Method to make a sound
    void makeSound() {//Walk
        System.out.println("The animal makes a sound");
    }
}

// Derived class
class Dog extends Animal { //Class Driver extends Person
    // Additional attribute for Dog
    String License;// String LicenseType

    // Constructor
    Dog(String name, int age, String license) {
        super(name, age);  // Call the constructor of the base class
        this.License = license;
    }

    // Override the makeSound method
    @Override
    void makeSound() {
        System.out.println("The dog barks");
    }

    // Method to display dog details
    @Override
    void displayInfo() {
        super.displayInfo();  // Call the method from the base class
        System.out.println("Breed: " + License);
    }
}
