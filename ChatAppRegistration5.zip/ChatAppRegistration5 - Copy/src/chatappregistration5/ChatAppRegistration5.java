/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatappregistration5;


import javax.swing.JOptionPane;

public class ChatAppRegistration5 {

    // Class variables
    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;

    // Constructor
    public ChatAppRegistration5(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Username validation (unchanged)
    public boolean checkUserName(String username) {
        if (username.length() > 5) {
            return false;
        }
        
        boolean hasUnderscore = false;
        for (int i = 0; i < username.length(); i++) {
            if (username.charAt(i) == '_') {
                hasUnderscore = true;
                break;
            }
        }
        return hasUnderscore;
    }

    // Password validation (unchanged)
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    // Cell number validation (unchanged)
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber.matches("^\\+27\\d{9}$");
    }

    // Registration method (unchanged)
    public String registerUser(String username, String password, String cellNumber) {
        boolean validUser = checkUserName(username);
        boolean validPass = checkPasswordComplexity(password);
        boolean validCell = checkCellPhoneNumber(cellNumber);
        
        if (!validUser && !validPass && !validCell) {
            return "Registration failed:\n"
                 + "- Username must contain _ and be ≤5 characters\n"
                 + "- Password needs 8+ chars with capital, number & special char\n"
                 + "- Cell number must be SA format (+27 followed by 9 digits)";
        }
        else if (!validUser) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        else if (!validPass) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        else if (!validCell) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        else {
            this.username = username;
            this.password = password;
            this.cellNumber = cellNumber;
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
        }
    }

    // Login verification (unchanged)
    public boolean loginUser(String username, String password) {
        return this.username != null 
               && this.password != null 
               && this.username.equals(username) 
               && this.password.equals(password);
    }

    // Login status message (unchanged)
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Main method - CHANGED to use JOptionPane
    public static void main(String[] args) {
        // Get user details
        String firstName = JOptionPane.showInputDialog("=== CHAT APP REGISTRATION ===\nEnter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");
        
        ChatAppRegistration5 user = new ChatAppRegistration5(firstName, lastName);
        
        // Registration
        String username = JOptionPane.showInputDialog("\n=== REGISTER ===\nUsername:");
        String password = JOptionPane.showInputDialog("Password:");
        String cell = JOptionPane.showInputDialog("SA Cell Number (+27...):");
        
        String regResult = user.registerUser(username, password, cell);
        JOptionPane.showMessageDialog(null, regResult);
        
        // Login if registration succeeded
        if (regResult.contains("successfully")) {
            String loginUser = JOptionPane.showInputDialog("\n=== LOGIN ===\nUsername:");
            String loginPass = JOptionPane.showInputDialog("Password:");
            
            boolean loggedIn = user.loginUser(loginUser, loginPass);
            JOptionPane.showMessageDialog(null, user.returnLoginStatus(loggedIn));
        }
    }
}
