/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */


import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class ChatAppFinal5 

{

    // Basic user info
    
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;
    private Object username;

    // Constructor for names
    public ChatAppFinal5(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Checks username rules
    public boolean checkUserName(String username) {
        if (username.length() > 9) {
            return false;
        }

        boolean hasUnderscore = false;
        for (int i = 0; i < username.length(); i++) {
            if (username.charAt(i) == '_') {
                hasUnderscore = true;
                break;
            }
        }
        return hasUnderscore;
    }

    // Checks password complexity
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 12) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    // Checks cell number format
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber.matches("^\\+27\\d{9}$");
    }

    // Registers the user with all 3 checks
    public String registerUser(String username, String password, String cellNumber) {
        boolean validUser = checkUserName(username);
        boolean validPass = checkPasswordComplexity(password);
        boolean validCell = checkCellPhoneNumber(cellNumber);

        if (!validUser && !validPass && !validCell) {
            return "Registration failed:\n"
                    + "- Username must contain _ and be ≤9 characters\n"
                    + "- Password needs 8+ chars with capital, number & special char\n"
                    + "- Cell number must be SA format (+27 followed by 9 digits)";
        } else if (!validUser) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        } else if (!validPass) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        } else if (!validCell) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        } else {
            this.username = username;
            this.password = password;
            this.cellNumber = cellNumber;
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
        }
    }

    // Log the user in
    public boolean loginUser(String username, String password) {
        return this.username != null
                && this.password != null
                && this.username.equals(username)
                && this.password.equals(password);
    }

    // Return login status
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // ====== MESSAGE SYSTEM (PART 2) ======
    public static class Message {
        private String id;
        private String recipient;
        private String messageText;
        private String hash;

        public Message(String id, String recipient, String messageText) {
            this.id = id;
            this.recipient = recipient;
            this.messageText = messageText;
        }

        public void generateHash() {
            String firstTwo = id.substring(0, 2);
            String[] words = messageText.trim().split(" ");
            String first = words[0].toUpperCase();
            String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
            this.hash = firstTwo + ":" + first + last;
        }

        public void printMessage() {
            System.out.println("ID: " + id);
            System.out.println("To: " + recipient);
            System.out.println("Message: " + messageText);
            System.out.println("Hash: " + hash);
        }
    }

    public static class MessageManager {
        private ArrayList<Message> messages = new ArrayList<>();
        private int totalSent = 0;

        public boolean checkRecipientCell(String number) {
            return number.length() <= 13 && number.startsWith("+");
        }

        public String generateMessageID() {
            Random rand = new Random();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                sb.append(rand.nextInt(10));
            }
            return sb.toString();
        }

        public void sendMessage(Message m) {
            messages.add(m);
            totalSent++;
        }

        public void storeMessage(Message m) {
            messages.add(m);
        }

        public int returnTotalMessages() {
            return totalSent;
        }
    }

    // ====== MAIN METHOD ======
    public static void main(String[] args) {
        String firstName = JOptionPane.showInputDialog("=== CHAT APP REGISTRATION ===\nEnter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        ChatAppFinal5 user = new ChatAppFinal5(firstName, lastName);

        // Registration
        String username = JOptionPane.showInputDialog("Username:");
        String password = JOptionPane.showInputDialog("Password:");
        String cell = JOptionPane.showInputDialog("SA Cell Number (+27...):");

        String regResult = user.registerUser(username, password, cell);
        JOptionPane.showMessageDialog(null, regResult);

        // Login
        if (regResult.contains("successfully")) {
            String loginUser = JOptionPane.showInputDialog("Login Username:");
            String loginPass = JOptionPane.showInputDialog("Login Password:");

            boolean loggedIn = user.loginUser(loginUser, loginPass);
            JOptionPane.showMessageDialog(null, user.returnLoginStatus(loggedIn));

            if (loggedIn) {
                // Start messaging
                Scanner scanner = new Scanner(System.in);
                MessageManager manager = new MessageManager();
                boolean chatting = true;

                while (chatting) {
                    System.out.println("\n=== QUICKCHAT MENU ===");
                    System.out.println("1. Send Message");
                    System.out.println("2. Show Recent Messages (Coming Soon)");
                    System.out.println("3. Quit");
                    System.out.print("Choose option: ");
                    String opt = scanner.nextLine();

                    switch (opt) {
                        case "1":
                            System.out.print("How many messages do you want to send? ");
                            int count = Integer.parseInt(scanner.nextLine());

                            for (int i = 0; i < count; i++) {
                                System.out.print("Enter recipient number (+CountryCode): ");
                                String rec = scanner.nextLine();

                                if (!manager.checkRecipientCell(rec)) {
                                    System.out.println("Invalid number. Must start with + and be ≤13 characters.");
                                    continue;
                                }

                                System.out.print("Enter message text: ");
                                String text = scanner.nextLine();

                                if (text.length() > 250) {
                                    System.out.println("Message too long. Exceeded by " + (text.length() - 250) + " characters.");
                                    continue;
                                }

                                System.out.print("Choose action (Send / Disregard / Store): ");
                                String action = scanner.nextLine();

                                Message m = new Message(manager.generateMessageID(), rec, text);
                                m.generateHash();

                                switch (action.toLowerCase()) {
                                    case "send":
                                        manager.sendMessage(m);
                                        System.out.println("Message sent.");
                                        break;
                                    case "store":
                                        manager.storeMessage(m);
                                        System.out.println("Message stored.");
                                        break;
                                    case "disregard":
                                        System.out.println("Message disregarded.");
                                        break;
                                    default:
                                        System.out.println("Invalid action.");
                                }
                            }
                            break;

                        case "2":
                            System.out.println("Coming soon.");
                            break;

                        case "3":
                            chatting = false;
                            break;

                        default:
                            System.out.println("Invalid option.");
                    }
                }

                System.out.println("\nTotal messages sent: " + manager.returnTotalMessages());
            }
        }
    }
}

    

